function cntChar(){
		var str = prompt("Please enter any string", "malayalam");
		var len = str.length;
		var cnt = 0;
		document.writeln("no of chars = "+len);

}