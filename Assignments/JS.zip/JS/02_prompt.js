
function displayName(){
	

	var person = prompt("Please enter your name", "Tony Greig");

	if (person != null) {
		
		document.write("Hello ",person,"! How are you ??");
	}
}